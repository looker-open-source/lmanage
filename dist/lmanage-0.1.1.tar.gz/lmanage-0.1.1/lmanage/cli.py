import click
from lmanage import removeuser


@click.command()
@click.argument('removeuser')
@click.option("-d", "--days", help="How many days has the user to be removed been inactive for")
@click.option("-i", "--ini-file", help="Path to the ini file to use for sdk authentication")
@click.option("-l", "--looker-instance", help="In the ini file, which section to use (i.e. which Looker instance)")
# @click.option("-g", "--git-url", help="The git url of the LookML repo")
def mapper(**kwargs):
    removeuser.main(**kwargs)
